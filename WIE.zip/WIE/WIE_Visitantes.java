import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

class ReadMoreButtonListener implements ActionListener {
    private String additionalInfo;

    public ReadMoreButtonListener(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFrame infoFrame = new JFrame("Información Adicional");
        infoFrame.setSize(400, 300);
        infoFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTextArea infoTextArea = new JTextArea(additionalInfo);
        infoTextArea.setEditable(false);
        infoTextArea.setLineWrap(true);
        infoTextArea.setWrapStyleWord(true);

        infoFrame.add(new JScrollPane(infoTextArea));
        infoFrame.setVisible(true);
    }
}

public class WIE_Visitantes extends JFrame {

    public WIE_Visitantes() {
        // Configuración de la ventana principal
        setTitle("WhereInEAFIT");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel principal con una disposición vertical
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(255, 228, 225)); // Fondo rosa claro

        // Título y descripción en la parte superior
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(255, 228, 225));
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        JLabel titleLabel = new JLabel("Where in EAFIT");
        titleLabel.setFont(new Font("Serif", Font.BOLD, 32));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel welcomeLabel = new JLabel("<html><center>¡Bienvenido a Where in EAFIT para VISITANTES!<br>" +
                "Where in EAFIT es tu guía completa para navegar y descubrir todo lo que la Universidad EAFIT tiene para ofrecer.</center></html>");
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(titleLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre elementos
        headerPanel.add(welcomeLabel);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Panel central con las secciones
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridLayout(3, 4, 10, 10)); // Disposición de 3x4 para los bloques de contenido
        contentPanel.setBackground(new Color(255, 228, 225));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Crear los paneles de cada categoría con botones
        String[] categories = {
            "Bloques", "Zonas de descanso", 
            "Restaurantes", 
            "Pago de parqueaderos", "Máquinas expendedoras", "Zonas de estudio", 
            "Otros puntos de interés", "Entradas Vehiculares","Entradas peatonales"
        };

        Map<String, String> additionalInfoMap = new HashMap<>();
        additionalInfoMap.put("Bloques", "Información adicional sobre los bloques de la universidad.\n" + 
        "Bloques de EAFIT\n" +
        "1. bloque de idiomas\n" +
        "3. departamentos de deportes y recreacion\n" +
        "4. piscina, camerinos y placa deportiva\n" +
        "7. espacios de aprendizaje, canetizacion, gimnasio, departamentos de compras y talleres de planta fisica\n" +
        "9. Universdiad de los ninos\n" +
        "10. programa atenea y esacios de estudio\n" +
        "12. departamento de desarrollo artistico\n" +
        "13. laboratorios de ingenieria y espacios de aprendizaje\n" +
        "14. laboratorios de ingenieria, espacios de aprendizaje y papeleria\n" +
        "15. laboratorio para la inovacion en el aprendizaje y fabrica de aprendizaje\n" +
        "16. Tienda azul amarelo y espacios de aprendizaje\n" +
        "17. laboratorio financiero, sala de descanso, espacios de aprendizaje y Bodeguita minimarket\n" +
        "18. Rectoria, vicerrectorias, direccion de investigacion, direccion de formacion inegral, oficina de direccionamiento estrategico, direccion de informatica, departamento de comunicación, departamento de practicas profesionales, sistemas integrados de gestion y control, eafit virtuel y librería de acentos\n" +
        "19. Escuela de ingenierias, EAFIT social, auditorio, maestria en administracion financiera, maestria en administracion, alta direccion y laboratorios de ciencias, centro de supercomputacion Apolo y aula de pedagogia inversa\n" +
        "19 20. Edificio escuela de Ciencias y espacios de aprendizaje\n" +
        "20 21. laboratorios de sismoresistencia y talleres de ingeniera de diseño de producto\n" +
        "22. taller de metamecanica\n" +
        "23. espacios de aprendizaje\n" +
        "26. Escuela de administracion, escuela de economia y finanzas, centro de investigaciones economicas y financieras, consultorio contable, laboratorios de psicologia y mercadeo\n" +
        "27. Escuela de derecho, sala de audiencias, auditorio fabricato, sala de unctad y espacios de aprendizaje\n" +
        "28. Auditorio fundadores\n" +
        "29. Oficina de Admisiones y Registro, Educacion Continua, Departamento de Tesoreria y Cartera, Dirección Administrativa y financiera, Escuela de Verano, Secretaría General, Dirección de Desarrollo Humano, Departamento de Desarrollo de Empleados, Departamento de Beneficios y Compensación, Departamento de Servicio Médico y Salud Ocupacional, Consultorio odontológico, Departamento de Desarrollo Estudiantil, grupos estudiantiles y representantes estudiantiles, Capellania, Fomune, oficinas profesores de Música, Espacios de aprendizaje y camerinos del Auditorio Fundadores.\n" +
        "30. departamento de musica, sala de ensayos y orquesta Sinfonica EAFIT\n" +
        "32. centro cultural biblioteca Luis Echavarria villegas (Salas de aprendizaje activo, sala de audiovisuales y sala patrimonial)\n" +
        "Centro de administracion documental\n" +
        "33,34,35. Espacios de aprendizaje\n" +
        "37. instituto de capacitacion e investigacion del plastico y el caucho (ICIPC)\n" +
        "38. Escuela de Humanidades, Escuela de Ciencias, Medialab, Auditonos 101 y 110, Acústica, Centro de Estudios en Lectura y Escritura (Cole), Consultorio Matemático y Físico, Datapol Laboratorio, Centro Multimedial y Espacios de aprendizaje.\n" +
        "39. Camerinos\n"); 
        additionalInfoMap.put("Zonas de descanso", "Información adicional sobre las zonas de descanso.\n" +
        "La sala de descanso, ubicada en el primer piso del bloque 17\n" + 
        "se convierte en un espacio de ocio y pausa para que los estudiantes puedan recargar energias y continuar con sus que haceres\n");
        additionalInfoMap.put("Restaurantes", "Información adicional sobre los restaurantes.\n" +
      "1. Aldea nikei\n" +
        "Lunes a Viernes 7:00 am a 9:00 pm - Sábados 7:00 am a 2:30 pm\n" +
        "Ubicación: cafeteria central, primer piso.\n" +
        "2. Bigo's\n" +
        "Lunes a Viernes de 6:00 am a 8:00 pm - Sábados 6:00 am a 2:00 pm\n" +
        "Ubicación: cafeteria central, primer piso.\n" +
        "3. Coffee House\n" +
        "Lunes a Viernes de 5:30 am a 8:00 pm - Sábados 7:00 am a 1:00 pm\n" +
        "Ubicación: plazoleta Centro Argos para la Innovación.\n" +
        "4. De Lolita\n" +
        "Lunes a Viernes 7:00 am a 8:00 pm - Sábados 7:00 am a 12:00 pm\n" +
        "Ubicación: Bloque 38 - frente a las cafeterias norte.\n" +
        "5. Dogger\n" +
        "Lunes a Viernes de 10:30 am a 8:30 pm - Sábados de 10:00 am a 3:00 pm\n" +
        "Ubicación: Contenedor, plazoleta del estudiante.\n" +
        "6. Dunkin' Donuts\n" +
        "Lunes a Viernes 6:00 am a 8:00 pm - Sábados 7:00 am a 1:00 pm\n" +
        "Ubicación: cafeteria central, burbuja segundo piso.\n" +
        "7. El Tejadito\n" +
        "Lunes a Viernes 6:30 am a 8:00 pm - Sábados 7:00 am a 12:30 pm\n" +
        "Ubicación: cafeteria norte.\n" +
        "8. Frisby\n" +
        "Lunes a Viernes de 10:00 am a 8:30 pm - Sábados 10:00 am a 3:00 pm\n" +
        "Ubicación: cafeteria central, primer piso.\n" +
        "9. Home Food\n" +
        "Lunes a Viernes de 7:00 am a 8:00 pm - Sábados de 7:00 am a 2:00 pm\n" +
        "Ubicación: cafeteria central, primer piso.\n" +
        "10. Juan Valdez Café\n" +
        "Lunes a Viernes 6:30 am a 8:30 pm - Sábados 7:00 am a 2:00 pm\n" +
        "Ubicación: cafeteria norte.\n" +
        "11. La Cafeteria\n" +
        "Lunes a Viernes 7:00 am a 7:00 pm - Sábados 7:00 am a 1:00 pm\n" +
        "Ubicación: Bloque G1 - Idiomas - piso 5.\n" +
        "12. Madelo\n" +
        "Lunes a Viernes de 9:00 am a 8:00 pm - Sábados 8:00 am a 4:00 pm\n" +
        "Ubicación: Contenedor - parqueaderos zona sur.\n" +
        "13. Mi Buñuelo\n" +
        "Lunes a Viernes de 6:00 am a 9:00 pm - Sábados 6:00 am a 3:00 pm\n" +
        "Ubicación: cafeteria central, segundo piso.\n" +
        "14. Pimientos\n" +
        "Lunes a Viernes de 7:30 am a 7:45 pm - Sábados 10:00 am a 3:00 pm\n" +
        "Ubicación: cafeteria norte.\n" +
        "15. Plural\n" +
        "Lunes a Viernes 7:00 am a 8:00 pm - Sábados 7:00 am a 12:00 pm\n" +
        "Ubicación: Bloque 38 - frente a las cafeterias.\n" +
        "16. Subway\n" +
        "Lunes a Viernes de 8:00 am a 8:00 pm - Sábados 8:00 am a 3:00 pm\n" +
        "Ubicación: Contenedor - parqueaderos zona sur.\n" +
        "17. Taco Factory\n" +
        "Lunes a Viernes de 11:00 am a 7:00 pm - Sábados 9:30 am a 2:00 pm\n" +
        "Ubicación: Cafeteria central, piso 2.\n");
        additionalInfoMap.put("Pago de parqueaderos", "Información adicional sobre el pago de parqueaderos.\n"+
        "Tarifa Visitante: 3.000 pesos la hora. Máximo 18.000 pesos\n"+
        "bloque 20\n"+
        "bloque 33\n"+
        "bloque 38 (FUERA DE SERVICIO) \n"+
        "bloque 18\n" );
        additionalInfoMap.put("Máquinas expendedoras", "Información adicional sobre las máquinas expendedoras.\n"+
        "bloque 18\n"+
        "bloque 15\n"+
        "bloque 38\n"+
        "bloque 9\n"+
        "bloque 33\n");
        additionalInfoMap.put("Zonas de estudio", "Información adicional sobre las zonas de estudio.\n"+ 
        "Biblioteca\n"+
        "bloque 32\n");
        additionalInfoMap.put("Otros puntos de interés", "Información adicional sobre otros puntos de interés.\n"+
        "Oficina de carnetización\n" +
        "Lunes a Viernes: 8:00 a.m. a 12:00 m. y 2:00 p.m. a 6:00 p.m.\n" +
        "Sábados: 8:00 a.m. a 12:00 m.\n" +
        "Domingos y Festivos: Cerrado\n\n" +

        "Azul Amarelo\n" +
        "Lunes a Viernes: 8:30 a.m. a 6:30 p.m.\n" +
        "Sábados: 10:00 a.m. a 1:00 p.m.\n\n" +

        "Gimnasio Vivo\n" +
        "Lunes a Jueves: 6:00 a.m. a 9:00 p.m.\n" +
        "Viernes: 6:00 a.m. a 8:00 p.m.\n" +
        "Sábados: 8:00 a.m. a 2:00 p.m.\n\n" +

        "Librería de Acentos\n" +
        "Lunes a Viernes: 8:00 a.m. a 7:00 p.m.\n" +
        "Sábados: 9:00 a.m. a 1:00 p.m.\n\n" +

        "La Bodeguita\n" +
        "Lunes a Viernes: 8:00 a.m. a 8:00 p.m.\n" +
        "Sábados: 9:00 a.m. a 1:00 p.m.\n\n" +

        "Servicios Bancarios\n" +
        "Lunes a Viernes: 9:00 a.m. a 12:00 p.m.\n" +
        "Sábados y Domingos: Cerrado\n\n" +

        "Crown Cuts\n" +
        "Lunes a Viernes: 9:00 a.m. a 7:00 p.m.\n" +
        "Sábados: 9:00 a.m. a 2:00 p.m.\n\n" +

        "Pasteur Droguería\n" +
        "Lunes a Viernes: 7:30 a.m. a 8:00 p.m.\n" +
        "Sábados: 8:00 a.m. a 2:00 p.m.\n\n" +

        "Rose\n" +
        "Lunes a Viernes: 8:00 a.m. a 7:00 p.m.\n" +
        "Sábados: 8:00 a.m. a 2:00 p.m.\n\n" +

        "Servicio Médico\n" +
        "Lunes a Viernes: 8:00 a.m. a 12:00 p.m. y 1:00 p.m. a 5:00 p.m.\n");
        additionalInfoMap.put("Entradas Vehiculares", "Información adicional sobre las entradas vehiculares.\n" +
        "Porteria de ingreso vehicular instituto del plastico y caucho \n" +
                "Horario de atención:\n" +
                "Lunes a viernes: 5:00 a.m. a 10:30 p.m.\n" +
                "Sábados: 6:00 a.m. a 6:00 p.m.\n" +
                "Domingos y festivos: Cerrado\n" +
                " \n" +
                "Porteria vehicular edificio de ingenierias \n" +
                "Horario de atención:\n" +
                "Lunes a viernes: 5:00 a.m. a 10:30 p.m.\n" +
                "Sábados: 6:00 a.m. a 6:00 p.m.\n" +
                "Domingos y festivos: Cerrado\n");

        additionalInfoMap.put("Entradas peatonales", "Información adicional sobre las entradas peatonales.\n"+
        "1. porteria peatonal principal ubicada avenida Las Vegas\n" +
        "Lunes a Viernes\n" +
        "Ingreso 5:00 a.m. - 10:30 p.m.\n" +
        "Salida hasta las 10:30 p.m.\n" +
        "Sábados, Domingos y Festivos\n" +
        "Ingreso 6:00 a.m. - 6:00 p.m.\n" +
        "Salida hasta las 6:00 p.m.\n" +

        "2. porteria peatonal de la calle 4 sur\n" +
        "Lunes a Viernes\n" +
        "Ingreso 5:00 a.m. - 10:30 p.m.\n" +
        "Salida hasta las 10:30 p.m.\n" +
        "Sábados\n" +
        "Ingreso 6:00 a.m. - 6:00 p.m.\n" +
        "Salida hasta las 6:00 p.m.\n" +
        "Domingos y Festivos\n" +
        "CERRADA\n" +
        
        "3. porteria peatonal Las Vegas sector Aguacatala\n" +
        "Lunes a Viernes\n" +
        "Ingreso 5:00 a.m. - 10:30 p.m.\n" +
        "Salida hasta las 10:30 p.m.\n" +
        "Sábados\n" +
        "Ingreso 6:00 a.m. - 6:00 p.m.\n" +
        "Salida hasta las 7:00 p.m.\n" +
        "Domingos y Festivos\n" +
        "Ingreso 6:00 a.m. - 6:00 p.m.\n" +
        "Salida hasta las 6:00 p.m.\n" +

        "4. porteria peatonal edificio de ingenierías\n" +
        "Lunes a Viernes\n" +
        "Ingreso 5:00 a.m. - 10:30 p.m.\n" +
        "Salida hasta las 10:30 p.m.\n" +
        "Sábados\n" +
        "Ingreso 6:00 a.m. - 6:00 p.m.\n" +
        "Salida hasta las 6:00 p.m.\n" +
        "Domingos y Festivos\n" +
        "CERRADA\n" +

        "5. porteria peatonal avenida Regional / edificio Argos\n" +
        "Lunes a Viernes\n" +
        "Ingreso 5:00 a.m. - 10:30 p.m.\n" +
        "Salida hasta las 10:30 p.m.\n" +
        "Sábados, Domingos y Festivos\n" +
        "Ingreso 6:00 a.m. - 6:00 p.m.\n" +
        "Salida hasta las 6:00 p.m.\n" +

        "6. porteria peatonal parque Los Guayabos (calle 5 sur)\n" +
        "Lunes a Viernes\n" +
        "Ingreso 5:00 a.m. - 10:30 p.m.\n" +
        "Salida hasta las 10:30 p.m.\n" +
        "Sábados\n" +
        "Ingreso 6:00 a.m. - 6:00 p.m.\n" +
        "Salida hasta las 6:00 p.m.\n" +
        "Domingos y Festivos\n" +
        "CERRADA\n" +

        "7. porteria peatonal parque Los Guayabos (avenida Las Vegas)\n" +
        "Lunes a Viernes\n" +
        "Ingreso 5:00 a.m. - 10:30 p.m.\n" +
        "Salida hasta las 10:30 p.m.\n" +
        "Sábados\n" +
        "Ingreso 6:00 a.m. - 6:00 p.m.\n" +
        "Salida hasta las 6:00 p.m.\n" +
        "Domingos y Festivos\n" +
        "CERRADA\n");


        for (String category : categories) {
            JPanel categoryPanel = new JPanel();
            categoryPanel.setLayout(new BorderLayout());
            categoryPanel.setBackground(Color.WHITE);
            categoryPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            JLabel categoryLabel = new JLabel(category, SwingConstants.CENTER);
            categoryLabel.setFont(new Font("Arial", Font.BOLD, 14));

            JButton readMoreButton = new JButton("Read More");
            readMoreButton.addActionListener(new ReadMoreButtonListener(additionalInfoMap.get(category)));

            categoryPanel.add(categoryLabel, BorderLayout.CENTER);
            categoryPanel.add(readMoreButton, BorderLayout.SOUTH);

            contentPanel.add(categoryPanel);
        }

        mainPanel.add(contentPanel, BorderLayout.CENTER);

        // Agregar el panel principal al JFrame
        add(mainPanel);
    }

    public static void main(String[] args) {
        // Ejecutar la interfaz gráfica
        SwingUtilities.invokeLater(() -> {
            WIE_Visitantes frame = new WIE_Visitantes();
            frame.setVisible(true);
        });
    }
}